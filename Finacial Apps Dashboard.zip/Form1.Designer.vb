﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Button15 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button14 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button12 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button13 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button10 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button11 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button9 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button7 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button8 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button6 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button5 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button4 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button3 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button2 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2CircleButton7 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2ControlBox3 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2ControlBox2 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2ControlBox1 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2Button18 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button17 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button16 = New Guna.UI2.WinForms.Guna2Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Guna2CircleButton1 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2Separator1 = New Guna.UI2.WinForms.Guna2Separator()
        Me.Guna2DragControl1 = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Guna2Panel3 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Panel5 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Button20 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2CircleButton2 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2Button19 = New Guna.UI2.WinForms.Guna2Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Guna2Panel4 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Guna2Panel6 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Guna2GradientPanel1 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Guna2Panel7 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Button21 = New Guna.UI2.WinForms.Guna2Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Guna2CircleButton3 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Guna2Panel8 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Button22 = New Guna.UI2.WinForms.Guna2Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Guna2CircleButton4 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Guna2Panel9 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Button23 = New Guna.UI2.WinForms.Guna2Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Guna2CircleButton5 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Guna2Panel10 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Button24 = New Guna.UI2.WinForms.Guna2Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Guna2CircleButton6 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.CartesianChart1 = New LiveCharts.WinForms.CartesianChart()
        Me.Guna2Panel11 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Guna2Panel12 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.PieChart1 = New LiveCharts.WinForms.PieChart()
        Me.Guna2CircleButton8 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2PictureBox6 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox5 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox4 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox3 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2CircleButton9 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2DataGridView1 = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Guna2Panel1.SuspendLayout()
        Me.Guna2Panel2.SuspendLayout()
        Me.Guna2Panel3.SuspendLayout()
        Me.Guna2Panel5.SuspendLayout()
        Me.Guna2Panel4.SuspendLayout()
        Me.Guna2Panel6.SuspendLayout()
        Me.Guna2GradientPanel1.SuspendLayout()
        Me.Guna2Panel7.SuspendLayout()
        Me.Guna2Panel8.SuspendLayout()
        Me.Guna2Panel9.SuspendLayout()
        Me.Guna2Panel10.SuspendLayout()
        Me.Guna2Panel11.SuspendLayout()
        Me.Guna2Panel12.SuspendLayout()
        CType(Me.Guna2PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.BorderRadius = 10
        Me.Guna2Elipse1.TargetControl = Me
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button15)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button14)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button12)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button13)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button10)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button11)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button9)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button7)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button8)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button6)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button5)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button4)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button3)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button2)
        Me.Guna2Panel1.Controls.Add(Me.Guna2Button1)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Guna2Panel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 51)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(189, 789)
        Me.Guna2Panel1.TabIndex = 0
        '
        'Guna2Button15
        '
        Me.Guna2Button15.Animated = True
        Me.Guna2Button15.CheckedState.Parent = Me.Guna2Button15
        Me.Guna2Button15.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button15.CustomImages.Parent = Me.Guna2Button15
        Me.Guna2Button15.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button15.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button15.HoverState.Parent = Me.Guna2Button15
        Me.Guna2Button15.Location = New System.Drawing.Point(3, 598)
        Me.Guna2Button15.Name = "Guna2Button15"
        Me.Guna2Button15.ShadowDecoration.Parent = Me.Guna2Button15
        Me.Guna2Button15.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button15.TabIndex = 14
        Me.Guna2Button15.Text = "Entity Management"
        Me.Guna2Button15.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button14
        '
        Me.Guna2Button14.Animated = True
        Me.Guna2Button14.CheckedState.Parent = Me.Guna2Button14
        Me.Guna2Button14.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button14.CustomImages.Parent = Me.Guna2Button14
        Me.Guna2Button14.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button14.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button14.HoverState.Parent = Me.Guna2Button14
        Me.Guna2Button14.Location = New System.Drawing.Point(3, 567)
        Me.Guna2Button14.Name = "Guna2Button14"
        Me.Guna2Button14.ShadowDecoration.Parent = Me.Guna2Button14
        Me.Guna2Button14.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button14.TabIndex = 13
        Me.Guna2Button14.Text = "Base Management"
        Me.Guna2Button14.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button12
        '
        Me.Guna2Button12.Animated = True
        Me.Guna2Button12.CheckedState.Parent = Me.Guna2Button12
        Me.Guna2Button12.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.expand_arrow_127px2
        Me.Guna2Button12.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.expand_arrow_127px1
        Me.Guna2Button12.CustomImages.Parent = Me.Guna2Button12
        Me.Guna2Button12.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button12.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button12.HoverState.Parent = Me.Guna2Button12
        Me.Guna2Button12.Location = New System.Drawing.Point(3, 536)
        Me.Guna2Button12.Name = "Guna2Button12"
        Me.Guna2Button12.ShadowDecoration.Parent = Me.Guna2Button12
        Me.Guna2Button12.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button12.TabIndex = 12
        Me.Guna2Button12.Text = "User Management"
        Me.Guna2Button12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button13
        '
        Me.Guna2Button13.Animated = True
        Me.Guna2Button13.CheckedState.Parent = Me.Guna2Button13
        Me.Guna2Button13.CustomBorderThickness = New System.Windows.Forms.Padding(4, 0, 0, 0)
        Me.Guna2Button13.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.user_127px
        Me.Guna2Button13.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.user_127px_png2
        Me.Guna2Button13.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button13.CustomImages.Parent = Me.Guna2Button13
        Me.Guna2Button13.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button13.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button13.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button13.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button13.HoverState.Parent = Me.Guna2Button13
        Me.Guna2Button13.Location = New System.Drawing.Point(3, 487)
        Me.Guna2Button13.Name = "Guna2Button13"
        Me.Guna2Button13.ShadowDecoration.Parent = Me.Guna2Button13
        Me.Guna2Button13.Size = New System.Drawing.Size(183, 45)
        Me.Guna2Button13.TabIndex = 11
        Me.Guna2Button13.Text = "Administration"
        Me.Guna2Button13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button13.TextOffset = New System.Drawing.Point(30, 0)
        '
        'Guna2Button10
        '
        Me.Guna2Button10.Animated = True
        Me.Guna2Button10.CheckedState.Parent = Me.Guna2Button10
        Me.Guna2Button10.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button10.CustomImages.Parent = Me.Guna2Button10
        Me.Guna2Button10.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button10.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button10.HoverState.Parent = Me.Guna2Button10
        Me.Guna2Button10.Location = New System.Drawing.Point(3, 439)
        Me.Guna2Button10.Name = "Guna2Button10"
        Me.Guna2Button10.ShadowDecoration.Parent = Me.Guna2Button10
        Me.Guna2Button10.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button10.TabIndex = 10
        Me.Guna2Button10.Text = "Upload History"
        Me.Guna2Button10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button11
        '
        Me.Guna2Button11.Animated = True
        Me.Guna2Button11.CheckedState.Parent = Me.Guna2Button11
        Me.Guna2Button11.CustomBorderThickness = New System.Windows.Forms.Padding(4, 0, 0, 0)
        Me.Guna2Button11.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.increase_127px_png1
        Me.Guna2Button11.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.increase_127px
        Me.Guna2Button11.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button11.CustomImages.Parent = Me.Guna2Button11
        Me.Guna2Button11.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button11.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button11.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button11.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button11.HoverState.Parent = Me.Guna2Button11
        Me.Guna2Button11.Location = New System.Drawing.Point(3, 394)
        Me.Guna2Button11.Name = "Guna2Button11"
        Me.Guna2Button11.ShadowDecoration.Parent = Me.Guna2Button11
        Me.Guna2Button11.Size = New System.Drawing.Size(183, 45)
        Me.Guna2Button11.TabIndex = 9
        Me.Guna2Button11.Text = "Activity"
        Me.Guna2Button11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button11.TextOffset = New System.Drawing.Point(30, 0)
        '
        'Guna2Button9
        '
        Me.Guna2Button9.Animated = True
        Me.Guna2Button9.CheckedState.Parent = Me.Guna2Button9
        Me.Guna2Button9.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button9.CustomImages.Parent = Me.Guna2Button9
        Me.Guna2Button9.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button9.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button9.HoverState.Parent = Me.Guna2Button9
        Me.Guna2Button9.Location = New System.Drawing.Point(3, 349)
        Me.Guna2Button9.Name = "Guna2Button9"
        Me.Guna2Button9.ShadowDecoration.Parent = Me.Guna2Button9
        Me.Guna2Button9.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button9.TabIndex = 8
        Me.Guna2Button9.Text = "Trade Payment"
        Me.Guna2Button9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button7
        '
        Me.Guna2Button7.Animated = True
        Me.Guna2Button7.CheckedState.Parent = Me.Guna2Button7
        Me.Guna2Button7.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button7.CustomImages.Parent = Me.Guna2Button7
        Me.Guna2Button7.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button7.HoverState.Parent = Me.Guna2Button7
        Me.Guna2Button7.Location = New System.Drawing.Point(3, 319)
        Me.Guna2Button7.Name = "Guna2Button7"
        Me.Guna2Button7.ShadowDecoration.Parent = Me.Guna2Button7
        Me.Guna2Button7.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button7.TabIndex = 7
        Me.Guna2Button7.Text = "All Tasks"
        Me.Guna2Button7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button8
        '
        Me.Guna2Button8.Animated = True
        Me.Guna2Button8.CheckedState.Parent = Me.Guna2Button8
        Me.Guna2Button8.CustomBorderThickness = New System.Windows.Forms.Padding(4, 0, 0, 0)
        Me.Guna2Button8.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.list_127px
        Me.Guna2Button8.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.list_127px_png2
        Me.Guna2Button8.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button8.CustomImages.Parent = Me.Guna2Button8
        Me.Guna2Button8.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button8.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button8.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button8.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button8.HoverState.Parent = Me.Guna2Button8
        Me.Guna2Button8.Location = New System.Drawing.Point(3, 271)
        Me.Guna2Button8.Name = "Guna2Button8"
        Me.Guna2Button8.ShadowDecoration.Parent = Me.Guna2Button8
        Me.Guna2Button8.Size = New System.Drawing.Size(183, 45)
        Me.Guna2Button8.TabIndex = 6
        Me.Guna2Button8.Text = "Tasks"
        Me.Guna2Button8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button8.TextOffset = New System.Drawing.Point(30, 0)
        '
        'Guna2Button6
        '
        Me.Guna2Button6.Animated = True
        Me.Guna2Button6.CheckedState.Parent = Me.Guna2Button6
        Me.Guna2Button6.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button6.CustomImages.Parent = Me.Guna2Button6
        Me.Guna2Button6.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button6.HoverState.Parent = Me.Guna2Button6
        Me.Guna2Button6.Location = New System.Drawing.Point(3, 226)
        Me.Guna2Button6.Name = "Guna2Button6"
        Me.Guna2Button6.ShadowDecoration.Parent = Me.Guna2Button6
        Me.Guna2Button6.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button6.TabIndex = 5
        Me.Guna2Button6.Text = "Program Configuration"
        Me.Guna2Button6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button5
        '
        Me.Guna2Button5.Animated = True
        Me.Guna2Button5.CheckedState.Parent = Me.Guna2Button5
        Me.Guna2Button5.CustomBorderThickness = New System.Windows.Forms.Padding(4, 0, 0, 0)
        Me.Guna2Button5.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.nas_127px_png2
        Me.Guna2Button5.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.nas_127px
        Me.Guna2Button5.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button5.CustomImages.ImageSize = New System.Drawing.Size(17, 17)
        Me.Guna2Button5.CustomImages.Parent = Me.Guna2Button5
        Me.Guna2Button5.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button5.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button5.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button5.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button5.HoverState.Parent = Me.Guna2Button5
        Me.Guna2Button5.Location = New System.Drawing.Point(3, 181)
        Me.Guna2Button5.Name = "Guna2Button5"
        Me.Guna2Button5.ShadowDecoration.Parent = Me.Guna2Button5
        Me.Guna2Button5.Size = New System.Drawing.Size(183, 45)
        Me.Guna2Button5.TabIndex = 4
        Me.Guna2Button5.Text = "Programs"
        Me.Guna2Button5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button5.TextOffset = New System.Drawing.Point(30, 0)
        '
        'Guna2Button4
        '
        Me.Guna2Button4.Animated = True
        Me.Guna2Button4.CheckedState.Parent = Me.Guna2Button4
        Me.Guna2Button4.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.expand_arrow_127px
        Me.Guna2Button4.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.expand_arrow_127px_png1
        Me.Guna2Button4.CustomImages.Parent = Me.Guna2Button4
        Me.Guna2Button4.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button4.HoverState.Parent = Me.Guna2Button4
        Me.Guna2Button4.Location = New System.Drawing.Point(3, 135)
        Me.Guna2Button4.Name = "Guna2Button4"
        Me.Guna2Button4.ShadowDecoration.Parent = Me.Guna2Button4
        Me.Guna2Button4.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button4.TabIndex = 3
        Me.Guna2Button4.Text = "Explorer"
        Me.Guna2Button4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button3
        '
        Me.Guna2Button3.Animated = True
        Me.Guna2Button3.CheckedState.Parent = Me.Guna2Button3
        Me.Guna2Button3.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.expand_arrow_127px
        Me.Guna2Button3.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.expand_arrow_127px_png1
        Me.Guna2Button3.CustomImages.Parent = Me.Guna2Button3
        Me.Guna2Button3.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button3.HoverState.Parent = Me.Guna2Button3
        Me.Guna2Button3.Location = New System.Drawing.Point(3, 102)
        Me.Guna2Button3.Name = "Guna2Button3"
        Me.Guna2Button3.ShadowDecoration.Parent = Me.Guna2Button3
        Me.Guna2Button3.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button3.TabIndex = 2
        Me.Guna2Button3.Text = "Leaders"
        Me.Guna2Button3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button2
        '
        Me.Guna2Button2.Animated = True
        Me.Guna2Button2.CheckedState.Parent = Me.Guna2Button2
        Me.Guna2Button2.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button2.CustomImages.Parent = Me.Guna2Button2
        Me.Guna2Button2.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button2.HoverState.Parent = Me.Guna2Button2
        Me.Guna2Button2.Location = New System.Drawing.Point(3, 69)
        Me.Guna2Button2.Name = "Guna2Button2"
        Me.Guna2Button2.ShadowDecoration.Parent = Me.Guna2Button2
        Me.Guna2Button2.Size = New System.Drawing.Size(183, 27)
        Me.Guna2Button2.TabIndex = 1
        Me.Guna2Button2.Text = "Home"
        Me.Guna2Button2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2Button1
        '
        Me.Guna2Button1.Animated = True
        Me.Guna2Button1.CheckedState.Parent = Me.Guna2Button1
        Me.Guna2Button1.CustomBorderThickness = New System.Windows.Forms.Padding(4, 0, 0, 0)
        Me.Guna2Button1.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.eye_127px
        Me.Guna2Button1.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.eye_127px_png1
        Me.Guna2Button1.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button1.CustomImages.Parent = Me.Guna2Button1
        Me.Guna2Button1.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button1.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button1.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button1.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button1.HoverState.Parent = Me.Guna2Button1
        Me.Guna2Button1.Location = New System.Drawing.Point(3, 18)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.ShadowDecoration.Parent = Me.Guna2Button1
        Me.Guna2Button1.Size = New System.Drawing.Size(183, 45)
        Me.Guna2Button1.TabIndex = 0
        Me.Guna2Button1.Text = "Views"
        Me.Guna2Button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button1.TextOffset = New System.Drawing.Point(30, 0)
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Panel2.Controls.Add(Me.Guna2CircleButton7)
        Me.Guna2Panel2.Controls.Add(Me.Guna2ControlBox3)
        Me.Guna2Panel2.Controls.Add(Me.Guna2ControlBox2)
        Me.Guna2Panel2.Controls.Add(Me.Guna2ControlBox1)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button18)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button17)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button16)
        Me.Guna2Panel2.Controls.Add(Me.Label1)
        Me.Guna2Panel2.Controls.Add(Me.Guna2CircleButton1)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Separator1)
        Me.Guna2Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2Panel2.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(1358, 51)
        Me.Guna2Panel2.TabIndex = 1
        '
        'Guna2CircleButton7
        '
        Me.Guna2CircleButton7.Animated = True
        Me.Guna2CircleButton7.CheckedState.Parent = Me.Guna2CircleButton7
        Me.Guna2CircleButton7.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.notification_127px_png2
        Me.Guna2CircleButton7.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.notification_127px
        Me.Guna2CircleButton7.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton7.CustomImages.Parent = Me.Guna2CircleButton7
        Me.Guna2CircleButton7.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton7.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton7.HoverState.Parent = Me.Guna2CircleButton7
        Me.Guna2CircleButton7.Location = New System.Drawing.Point(161, 13)
        Me.Guna2CircleButton7.Name = "Guna2CircleButton7"
        Me.Guna2CircleButton7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton7.ShadowDecoration.Parent = Me.Guna2CircleButton7
        Me.Guna2CircleButton7.Size = New System.Drawing.Size(25, 25)
        Me.Guna2CircleButton7.TabIndex = 10
        '
        'Guna2ControlBox3
        '
        Me.Guna2ControlBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MaximizeBox
        Me.Guna2ControlBox3.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2ControlBox3.HoverState.Parent = Me.Guna2ControlBox3
        Me.Guna2ControlBox3.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox3.Location = New System.Drawing.Point(1279, 12)
        Me.Guna2ControlBox3.Name = "Guna2ControlBox3"
        Me.Guna2ControlBox3.ShadowDecoration.Parent = Me.Guna2ControlBox3
        Me.Guna2ControlBox3.Size = New System.Drawing.Size(26, 26)
        Me.Guna2ControlBox3.TabIndex = 9
        '
        'Guna2ControlBox2
        '
        Me.Guna2ControlBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox
        Me.Guna2ControlBox2.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2ControlBox2.HoverState.Parent = Me.Guna2ControlBox2
        Me.Guna2ControlBox2.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox2.Location = New System.Drawing.Point(1248, 12)
        Me.Guna2ControlBox2.Name = "Guna2ControlBox2"
        Me.Guna2ControlBox2.ShadowDecoration.Parent = Me.Guna2ControlBox2
        Me.Guna2ControlBox2.Size = New System.Drawing.Size(26, 26)
        Me.Guna2ControlBox2.TabIndex = 8
        '
        'Guna2ControlBox1
        '
        Me.Guna2ControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox1.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2ControlBox1.HoverState.Parent = Me.Guna2ControlBox1
        Me.Guna2ControlBox1.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox1.Location = New System.Drawing.Point(1311, 12)
        Me.Guna2ControlBox1.Name = "Guna2ControlBox1"
        Me.Guna2ControlBox1.ShadowDecoration.Parent = Me.Guna2ControlBox1
        Me.Guna2ControlBox1.Size = New System.Drawing.Size(26, 26)
        Me.Guna2ControlBox1.TabIndex = 7
        '
        'Guna2Button18
        '
        Me.Guna2Button18.Animated = True
        Me.Guna2Button18.CheckedState.Parent = Me.Guna2Button18
        Me.Guna2Button18.CustomBorderThickness = New System.Windows.Forms.Padding(0, 0, 0, 4)
        Me.Guna2Button18.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button18.CustomImages.Parent = Me.Guna2Button18
        Me.Guna2Button18.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button18.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button18.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button18.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button18.HoverState.Parent = Me.Guna2Button18
        Me.Guna2Button18.Location = New System.Drawing.Point(604, 5)
        Me.Guna2Button18.Name = "Guna2Button18"
        Me.Guna2Button18.ShadowDecoration.Parent = Me.Guna2Button18
        Me.Guna2Button18.Size = New System.Drawing.Size(188, 41)
        Me.Guna2Button18.TabIndex = 6
        Me.Guna2Button18.Text = "Payable Finances"
        '
        'Guna2Button17
        '
        Me.Guna2Button17.Animated = True
        Me.Guna2Button17.CheckedState.Parent = Me.Guna2Button17
        Me.Guna2Button17.CustomBorderThickness = New System.Windows.Forms.Padding(0, 0, 0, 4)
        Me.Guna2Button17.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button17.CustomImages.Parent = Me.Guna2Button17
        Me.Guna2Button17.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button17.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button17.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button17.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button17.HoverState.Parent = Me.Guna2Button17
        Me.Guna2Button17.Location = New System.Drawing.Point(398, 5)
        Me.Guna2Button17.Name = "Guna2Button17"
        Me.Guna2Button17.ShadowDecoration.Parent = Me.Guna2Button17
        Me.Guna2Button17.Size = New System.Drawing.Size(188, 41)
        Me.Guna2Button17.TabIndex = 5
        Me.Guna2Button17.Text = "Payment Commitment"
        '
        'Guna2Button16
        '
        Me.Guna2Button16.Animated = True
        Me.Guna2Button16.CheckedState.Parent = Me.Guna2Button16
        Me.Guna2Button16.CustomBorderThickness = New System.Windows.Forms.Padding(0, 0, 0, 4)
        Me.Guna2Button16.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button16.CustomImages.Parent = Me.Guna2Button16
        Me.Guna2Button16.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Button16.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button16.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button16.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button16.HoverState.Parent = Me.Guna2Button16
        Me.Guna2Button16.Location = New System.Drawing.Point(192, 5)
        Me.Guna2Button16.Name = "Guna2Button16"
        Me.Guna2Button16.ShadowDecoration.Parent = Me.Guna2Button16
        Me.Guna2Button16.Size = New System.Drawing.Size(188, 41)
        Me.Guna2Button16.TabIndex = 4
        Me.Guna2Button16.Text = "Receivables Discounting"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(17, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 21)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "John Doe"
        '
        'Guna2CircleButton1
        '
        Me.Guna2CircleButton1.Animated = True
        Me.Guna2CircleButton1.CheckedState.Parent = Me.Guna2CircleButton1
        Me.Guna2CircleButton1.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.settings_127px_png1
        Me.Guna2CircleButton1.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.settings_127px
        Me.Guna2CircleButton1.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton1.CustomImages.Parent = Me.Guna2CircleButton1
        Me.Guna2CircleButton1.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton1.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton1.HoverState.Parent = Me.Guna2CircleButton1
        Me.Guna2CircleButton1.Location = New System.Drawing.Point(130, 13)
        Me.Guna2CircleButton1.Name = "Guna2CircleButton1"
        Me.Guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton1.ShadowDecoration.Parent = Me.Guna2CircleButton1
        Me.Guna2CircleButton1.Size = New System.Drawing.Size(25, 25)
        Me.Guna2CircleButton1.TabIndex = 2
        '
        'Guna2Separator1
        '
        Me.Guna2Separator1.FillColor = System.Drawing.SystemColors.ActiveBorder
        Me.Guna2Separator1.Location = New System.Drawing.Point(0, 44)
        Me.Guna2Separator1.Name = "Guna2Separator1"
        Me.Guna2Separator1.Size = New System.Drawing.Size(186, 10)
        Me.Guna2Separator1.TabIndex = 0
        '
        'Guna2DragControl1
        '
        Me.Guna2DragControl1.TargetControl = Me.Guna2Panel2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(211, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(173, 19)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Payment Commitment  /"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(390, 69)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 19)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Overview"
        '
        'Guna2Panel3
        '
        Me.Guna2Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Panel3.BorderRadius = 10
        Me.Guna2Panel3.Controls.Add(Me.Guna2Panel5)
        Me.Guna2Panel3.Controls.Add(Me.Guna2Panel4)
        Me.Guna2Panel3.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Panel3.Location = New System.Drawing.Point(215, 113)
        Me.Guna2Panel3.Name = "Guna2Panel3"
        Me.Guna2Panel3.ShadowDecoration.Parent = Me.Guna2Panel3
        Me.Guna2Panel3.Size = New System.Drawing.Size(618, 164)
        Me.Guna2Panel3.TabIndex = 6
        '
        'Guna2Panel5
        '
        Me.Guna2Panel5.Controls.Add(Me.Guna2Button20)
        Me.Guna2Panel5.Controls.Add(Me.Guna2CircleButton2)
        Me.Guna2Panel5.Controls.Add(Me.Guna2Button19)
        Me.Guna2Panel5.Controls.Add(Me.Label12)
        Me.Guna2Panel5.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Guna2Panel5.CustomBorderThickness = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Guna2Panel5.Dock = System.Windows.Forms.DockStyle.Right
        Me.Guna2Panel5.FillColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(74, Byte), Integer), CType(CType(81, Byte), Integer))
        Me.Guna2Panel5.Location = New System.Drawing.Point(349, 0)
        Me.Guna2Panel5.Name = "Guna2Panel5"
        Me.Guna2Panel5.ShadowDecoration.Parent = Me.Guna2Panel5
        Me.Guna2Panel5.Size = New System.Drawing.Size(269, 164)
        Me.Guna2Panel5.TabIndex = 1
        '
        'Guna2Button20
        '
        Me.Guna2Button20.Animated = True
        Me.Guna2Button20.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Button20.BorderRadius = 10
        Me.Guna2Button20.CheckedState.Parent = Me.Guna2Button20
        Me.Guna2Button20.CustomImages.Parent = Me.Guna2Button20
        Me.Guna2Button20.FillColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2Button20.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button20.ForeColor = System.Drawing.Color.Black
        Me.Guna2Button20.HoverState.Parent = Me.Guna2Button20
        Me.Guna2Button20.Location = New System.Drawing.Point(141, 106)
        Me.Guna2Button20.Name = "Guna2Button20"
        Me.Guna2Button20.ShadowDecoration.Parent = Me.Guna2Button20
        Me.Guna2Button20.Size = New System.Drawing.Size(119, 33)
        Me.Guna2Button20.TabIndex = 16
        Me.Guna2Button20.Text = "Link Accounts"
        '
        'Guna2CircleButton2
        '
        Me.Guna2CircleButton2.Animated = True
        Me.Guna2CircleButton2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton2.CheckedState.Parent = Me.Guna2CircleButton2
        Me.Guna2CircleButton2.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.right_arrow_127px_png2
        Me.Guna2CircleButton2.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.right_arrow_127px
        Me.Guna2CircleButton2.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton2.CustomImages.Parent = Me.Guna2CircleButton2
        Me.Guna2CircleButton2.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton2.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton2.HoverState.Parent = Me.Guna2CircleButton2
        Me.Guna2CircleButton2.Location = New System.Drawing.Point(233, 25)
        Me.Guna2CircleButton2.Name = "Guna2CircleButton2"
        Me.Guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton2.ShadowDecoration.Parent = Me.Guna2CircleButton2
        Me.Guna2CircleButton2.Size = New System.Drawing.Size(25, 25)
        Me.Guna2CircleButton2.TabIndex = 14
        '
        'Guna2Button19
        '
        Me.Guna2Button19.Animated = True
        Me.Guna2Button19.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Button19.BorderRadius = 10
        Me.Guna2Button19.CheckedState.Parent = Me.Guna2Button19
        Me.Guna2Button19.CustomImages.Parent = Me.Guna2Button19
        Me.Guna2Button19.FillColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button19.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button19.ForeColor = System.Drawing.Color.Black
        Me.Guna2Button19.HoverState.Parent = Me.Guna2Button19
        Me.Guna2Button19.Location = New System.Drawing.Point(16, 106)
        Me.Guna2Button19.Name = "Guna2Button19"
        Me.Guna2Button19.ShadowDecoration.Parent = Me.Guna2Button19
        Me.Guna2Button19.Size = New System.Drawing.Size(119, 33)
        Me.Guna2Button19.TabIndex = 15
        Me.Guna2Button19.Text = "Transfer Money"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(12, 25)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(108, 19)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "Universal Bank"
        '
        'Guna2Panel4
        '
        Me.Guna2Panel4.Controls.Add(Me.Label10)
        Me.Guna2Panel4.Controls.Add(Me.Label11)
        Me.Guna2Panel4.Controls.Add(Me.Label8)
        Me.Guna2Panel4.Controls.Add(Me.Label9)
        Me.Guna2Panel4.Controls.Add(Me.Label7)
        Me.Guna2Panel4.Controls.Add(Me.Label6)
        Me.Guna2Panel4.Controls.Add(Me.Label5)
        Me.Guna2Panel4.Controls.Add(Me.Label4)
        Me.Guna2Panel4.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Panel4.CustomBorderThickness = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Guna2Panel4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Guna2Panel4.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel4.Name = "Guna2Panel4"
        Me.Guna2Panel4.ShadowDecoration.Parent = Me.Guna2Panel4
        Me.Guna2Panel4.Size = New System.Drawing.Size(359, 164)
        Me.Guna2Panel4.TabIndex = 0
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(252, 126)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(58, 13)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "$20000.00"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Silver
        Me.Label11.Location = New System.Drawing.Point(252, 109)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 13)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "CREDIT CASH"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(167, 126)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 13)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "USD"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Silver
        Me.Label9.Location = New System.Drawing.Point(167, 109)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(65, 13)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "CURRENCY"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(22, 126)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Universal Bank"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Silver
        Me.Label6.Location = New System.Drawing.Point(22, 109)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "BANK"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(17, 49)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(169, 46)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "$7425.50"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(21, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(114, 19)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Available Funds"
        '
        'Guna2Panel6
        '
        Me.Guna2Panel6.BorderRadius = 10
        Me.Guna2Panel6.Controls.Add(Me.Label14)
        Me.Guna2Panel6.Controls.Add(Me.Label15)
        Me.Guna2Panel6.Controls.Add(Me.Label13)
        Me.Guna2Panel6.CustomBorderColor = System.Drawing.Color.Transparent
        Me.Guna2Panel6.CustomBorderThickness = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Guna2Panel6.FillColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(74, Byte), Integer), CType(CType(81, Byte), Integer))
        Me.Guna2Panel6.Location = New System.Drawing.Point(853, 86)
        Me.Guna2Panel6.Name = "Guna2Panel6"
        Me.Guna2Panel6.ShadowDecoration.Parent = Me.Guna2Panel6
        Me.Guna2Panel6.Size = New System.Drawing.Size(480, 191)
        Me.Guna2Panel6.TabIndex = 7
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(13, 100)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(78, 19)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "Mastercard"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Silver
        Me.Label15.Location = New System.Drawing.Point(13, 76)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 15)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "CARD TYPE"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(12, 25)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(76, 19)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "Your Card"
        '
        'Guna2GradientPanel1
        '
        Me.Guna2GradientPanel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2GradientPanel1.BorderRadius = 10
        Me.Guna2GradientPanel1.Controls.Add(Me.Label19)
        Me.Guna2GradientPanel1.Controls.Add(Me.Label18)
        Me.Guna2GradientPanel1.Controls.Add(Me.Label17)
        Me.Guna2GradientPanel1.Controls.Add(Me.Label16)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2PictureBox2)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2PictureBox1)
        Me.Guna2GradientPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.Guna2GradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.Guna2GradientPanel1.Location = New System.Drawing.Point(965, 60)
        Me.Guna2GradientPanel1.Name = "Guna2GradientPanel1"
        Me.Guna2GradientPanel1.ShadowDecoration.Parent = Me.Guna2GradientPanel1
        Me.Guna2GradientPanel1.Size = New System.Drawing.Size(360, 203)
        Me.Guna2GradientPanel1.TabIndex = 16
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(244, 175)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(62, 19)
        Me.Label19.TabIndex = 17
        Me.Label19.Text = "22  /  24"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(244, 156)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(45, 13)
        Me.Label18.TabIndex = 16
        Me.Label18.Text = "Expired"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(20, 156)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(84, 20)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "JOHN DOE"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Digital-7 Mono", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(16, 107)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(324, 28)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "1234    5642   1235   8596"
        '
        'Guna2Panel7
        '
        Me.Guna2Panel7.BorderRadius = 10
        Me.Guna2Panel7.Controls.Add(Me.Guna2Button21)
        Me.Guna2Panel7.Controls.Add(Me.Guna2PictureBox3)
        Me.Guna2Panel7.Controls.Add(Me.Label22)
        Me.Guna2Panel7.Controls.Add(Me.Label21)
        Me.Guna2Panel7.Controls.Add(Me.Guna2CircleButton3)
        Me.Guna2Panel7.Controls.Add(Me.Label20)
        Me.Guna2Panel7.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Panel7.Location = New System.Drawing.Point(215, 297)
        Me.Guna2Panel7.Name = "Guna2Panel7"
        Me.Guna2Panel7.ShadowDecoration.Parent = Me.Guna2Panel7
        Me.Guna2Panel7.Size = New System.Drawing.Size(263, 100)
        Me.Guna2Panel7.TabIndex = 17
        '
        'Guna2Button21
        '
        Me.Guna2Button21.Animated = True
        Me.Guna2Button21.CheckedState.Parent = Me.Guna2Button21
        Me.Guna2Button21.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.menu_vertical_127px
        Me.Guna2Button21.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.menu_vertical_127px_png3
        Me.Guna2Button21.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2Button21.CustomImages.Parent = Me.Guna2Button21
        Me.Guna2Button21.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Button21.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button21.ForeColor = System.Drawing.Color.White
        Me.Guna2Button21.HoverState.Parent = Me.Guna2Button21
        Me.Guna2Button21.Location = New System.Drawing.Point(225, 63)
        Me.Guna2Button21.Name = "Guna2Button21"
        Me.Guna2Button21.ShadowDecoration.Parent = Me.Guna2Button21
        Me.Guna2Button21.Size = New System.Drawing.Size(24, 34)
        Me.Guna2Button21.TabIndex = 13
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(23, 72)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(58, 20)
        Me.Label22.TabIndex = 11
        Me.Label22.Text = "$55.00"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Silver
        Me.Label21.Location = New System.Drawing.Point(23, 42)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(81, 13)
        Me.Label21.TabIndex = 10
        Me.Label21.Text = "1234 **** 8911"
        '
        'Guna2CircleButton3
        '
        Me.Guna2CircleButton3.Animated = True
        Me.Guna2CircleButton3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton3.CheckedState.Parent = Me.Guna2CircleButton3
        Me.Guna2CircleButton3.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.copy_127px
        Me.Guna2CircleButton3.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.copy_127px_png1
        Me.Guna2CircleButton3.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton3.CustomImages.ImageSize = New System.Drawing.Size(15, 15)
        Me.Guna2CircleButton3.CustomImages.Parent = Me.Guna2CircleButton3
        Me.Guna2CircleButton3.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton3.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton3.HoverState.Parent = Me.Guna2CircleButton3
        Me.Guna2CircleButton3.Location = New System.Drawing.Point(86, 18)
        Me.Guna2CircleButton3.Name = "Guna2CircleButton3"
        Me.Guna2CircleButton3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton3.ShadowDecoration.Parent = Me.Guna2CircleButton3
        Me.Guna2CircleButton3.Size = New System.Drawing.Size(17, 21)
        Me.Guna2CircleButton3.TabIndex = 9
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Label20.Location = New System.Drawing.Point(22, 16)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(43, 19)
        Me.Label20.TabIndex = 8
        Me.Label20.Text = "EBAY"
        '
        'Guna2Panel8
        '
        Me.Guna2Panel8.BorderRadius = 10
        Me.Guna2Panel8.Controls.Add(Me.Guna2Button22)
        Me.Guna2Panel8.Controls.Add(Me.Guna2PictureBox4)
        Me.Guna2Panel8.Controls.Add(Me.Label23)
        Me.Guna2Panel8.Controls.Add(Me.Label24)
        Me.Guna2Panel8.Controls.Add(Me.Guna2CircleButton4)
        Me.Guna2Panel8.Controls.Add(Me.Label25)
        Me.Guna2Panel8.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Panel8.Location = New System.Drawing.Point(501, 297)
        Me.Guna2Panel8.Name = "Guna2Panel8"
        Me.Guna2Panel8.ShadowDecoration.Parent = Me.Guna2Panel8
        Me.Guna2Panel8.Size = New System.Drawing.Size(263, 100)
        Me.Guna2Panel8.TabIndex = 18
        '
        'Guna2Button22
        '
        Me.Guna2Button22.Animated = True
        Me.Guna2Button22.CheckedState.Parent = Me.Guna2Button22
        Me.Guna2Button22.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.menu_vertical_127px
        Me.Guna2Button22.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.menu_vertical_127px_png3
        Me.Guna2Button22.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2Button22.CustomImages.Parent = Me.Guna2Button22
        Me.Guna2Button22.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Button22.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button22.ForeColor = System.Drawing.Color.White
        Me.Guna2Button22.HoverState.Parent = Me.Guna2Button22
        Me.Guna2Button22.Location = New System.Drawing.Point(225, 63)
        Me.Guna2Button22.Name = "Guna2Button22"
        Me.Guna2Button22.ShadowDecoration.Parent = Me.Guna2Button22
        Me.Guna2Button22.Size = New System.Drawing.Size(24, 34)
        Me.Guna2Button22.TabIndex = 13
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(23, 72)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(58, 20)
        Me.Label23.TabIndex = 11
        Me.Label23.Text = "$65.00"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Silver
        Me.Label24.Location = New System.Drawing.Point(23, 42)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(81, 13)
        Me.Label24.TabIndex = 10
        Me.Label24.Text = "1234 **** 8911"
        '
        'Guna2CircleButton4
        '
        Me.Guna2CircleButton4.Animated = True
        Me.Guna2CircleButton4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton4.CheckedState.Parent = Me.Guna2CircleButton4
        Me.Guna2CircleButton4.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.copy_127px
        Me.Guna2CircleButton4.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.copy_127px_png1
        Me.Guna2CircleButton4.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton4.CustomImages.ImageSize = New System.Drawing.Size(15, 15)
        Me.Guna2CircleButton4.CustomImages.Parent = Me.Guna2CircleButton4
        Me.Guna2CircleButton4.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton4.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton4.HoverState.Parent = Me.Guna2CircleButton4
        Me.Guna2CircleButton4.Location = New System.Drawing.Point(126, 16)
        Me.Guna2CircleButton4.Name = "Guna2CircleButton4"
        Me.Guna2CircleButton4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton4.ShadowDecoration.Parent = Me.Guna2CircleButton4
        Me.Guna2CircleButton4.Size = New System.Drawing.Size(17, 21)
        Me.Guna2CircleButton4.TabIndex = 9
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Label25.Location = New System.Drawing.Point(22, 16)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(98, 19)
        Me.Label25.TabIndex = 8
        Me.Label25.Text = "MCDONALDS"
        '
        'Guna2Panel9
        '
        Me.Guna2Panel9.BorderRadius = 10
        Me.Guna2Panel9.Controls.Add(Me.Guna2Button23)
        Me.Guna2Panel9.Controls.Add(Me.Guna2PictureBox5)
        Me.Guna2Panel9.Controls.Add(Me.Label26)
        Me.Guna2Panel9.Controls.Add(Me.Label27)
        Me.Guna2Panel9.Controls.Add(Me.Guna2CircleButton5)
        Me.Guna2Panel9.Controls.Add(Me.Label28)
        Me.Guna2Panel9.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Panel9.Location = New System.Drawing.Point(787, 297)
        Me.Guna2Panel9.Name = "Guna2Panel9"
        Me.Guna2Panel9.ShadowDecoration.Parent = Me.Guna2Panel9
        Me.Guna2Panel9.Size = New System.Drawing.Size(263, 100)
        Me.Guna2Panel9.TabIndex = 18
        '
        'Guna2Button23
        '
        Me.Guna2Button23.Animated = True
        Me.Guna2Button23.CheckedState.Parent = Me.Guna2Button23
        Me.Guna2Button23.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.menu_vertical_127px
        Me.Guna2Button23.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.menu_vertical_127px_png3
        Me.Guna2Button23.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2Button23.CustomImages.Parent = Me.Guna2Button23
        Me.Guna2Button23.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Button23.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button23.ForeColor = System.Drawing.Color.White
        Me.Guna2Button23.HoverState.Parent = Me.Guna2Button23
        Me.Guna2Button23.Location = New System.Drawing.Point(225, 63)
        Me.Guna2Button23.Name = "Guna2Button23"
        Me.Guna2Button23.ShadowDecoration.Parent = Me.Guna2Button23
        Me.Guna2Button23.Size = New System.Drawing.Size(24, 34)
        Me.Guna2Button23.TabIndex = 13
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.White
        Me.Label26.Location = New System.Drawing.Point(23, 72)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(67, 20)
        Me.Label26.TabIndex = 11
        Me.Label26.Text = "$515.00"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Silver
        Me.Label27.Location = New System.Drawing.Point(23, 42)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(81, 13)
        Me.Label27.TabIndex = 10
        Me.Label27.Text = "1234 **** 8911"
        '
        'Guna2CircleButton5
        '
        Me.Guna2CircleButton5.Animated = True
        Me.Guna2CircleButton5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton5.CheckedState.Parent = Me.Guna2CircleButton5
        Me.Guna2CircleButton5.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.copy_127px
        Me.Guna2CircleButton5.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.copy_127px_png1
        Me.Guna2CircleButton5.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton5.CustomImages.ImageSize = New System.Drawing.Size(15, 15)
        Me.Guna2CircleButton5.CustomImages.Parent = Me.Guna2CircleButton5
        Me.Guna2CircleButton5.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton5.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton5.HoverState.Parent = Me.Guna2CircleButton5
        Me.Guna2CircleButton5.Location = New System.Drawing.Point(101, 18)
        Me.Guna2CircleButton5.Name = "Guna2CircleButton5"
        Me.Guna2CircleButton5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton5.ShadowDecoration.Parent = Me.Guna2CircleButton5
        Me.Guna2CircleButton5.Size = New System.Drawing.Size(17, 21)
        Me.Guna2CircleButton5.TabIndex = 9
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Label28.Location = New System.Drawing.Point(22, 16)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(73, 19)
        Me.Label28.TabIndex = 8
        Me.Label28.Text = "AMAZON"
        '
        'Guna2Panel10
        '
        Me.Guna2Panel10.BorderRadius = 10
        Me.Guna2Panel10.Controls.Add(Me.Guna2Button24)
        Me.Guna2Panel10.Controls.Add(Me.Guna2PictureBox6)
        Me.Guna2Panel10.Controls.Add(Me.Label29)
        Me.Guna2Panel10.Controls.Add(Me.Label30)
        Me.Guna2Panel10.Controls.Add(Me.Guna2CircleButton6)
        Me.Guna2Panel10.Controls.Add(Me.Label31)
        Me.Guna2Panel10.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Panel10.Location = New System.Drawing.Point(1073, 297)
        Me.Guna2Panel10.Name = "Guna2Panel10"
        Me.Guna2Panel10.ShadowDecoration.Parent = Me.Guna2Panel10
        Me.Guna2Panel10.Size = New System.Drawing.Size(263, 100)
        Me.Guna2Panel10.TabIndex = 18
        '
        'Guna2Button24
        '
        Me.Guna2Button24.Animated = True
        Me.Guna2Button24.CheckedState.Parent = Me.Guna2Button24
        Me.Guna2Button24.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.menu_vertical_127px
        Me.Guna2Button24.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.menu_vertical_127px_png3
        Me.Guna2Button24.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2Button24.CustomImages.Parent = Me.Guna2Button24
        Me.Guna2Button24.FillColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(65, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Guna2Button24.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button24.ForeColor = System.Drawing.Color.White
        Me.Guna2Button24.HoverState.Parent = Me.Guna2Button24
        Me.Guna2Button24.Location = New System.Drawing.Point(225, 63)
        Me.Guna2Button24.Name = "Guna2Button24"
        Me.Guna2Button24.ShadowDecoration.Parent = Me.Guna2Button24
        Me.Guna2Button24.Size = New System.Drawing.Size(24, 34)
        Me.Guna2Button24.TabIndex = 13
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.White
        Me.Label29.Location = New System.Drawing.Point(23, 72)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(67, 20)
        Me.Label29.TabIndex = 11
        Me.Label29.Text = "$315.00"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Silver
        Me.Label30.Location = New System.Drawing.Point(23, 42)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(81, 13)
        Me.Label30.TabIndex = 10
        Me.Label30.Text = "1234 **** 8911"
        '
        'Guna2CircleButton6
        '
        Me.Guna2CircleButton6.Animated = True
        Me.Guna2CircleButton6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton6.CheckedState.Parent = Me.Guna2CircleButton6
        Me.Guna2CircleButton6.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.copy_127px
        Me.Guna2CircleButton6.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.copy_127px_png1
        Me.Guna2CircleButton6.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton6.CustomImages.ImageSize = New System.Drawing.Size(15, 15)
        Me.Guna2CircleButton6.CustomImages.Parent = Me.Guna2CircleButton6
        Me.Guna2CircleButton6.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton6.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton6.HoverState.Parent = Me.Guna2CircleButton6
        Me.Guna2CircleButton6.Location = New System.Drawing.Point(100, 16)
        Me.Guna2CircleButton6.Name = "Guna2CircleButton6"
        Me.Guna2CircleButton6.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton6.ShadowDecoration.Parent = Me.Guna2CircleButton6
        Me.Guna2CircleButton6.Size = New System.Drawing.Size(17, 21)
        Me.Guna2CircleButton6.TabIndex = 9
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Label31.Location = New System.Drawing.Point(22, 16)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(72, 19)
        Me.Label31.TabIndex = 8
        Me.Label31.Text = "PS STORE"
        '
        'CartesianChart1
        '
        Me.CartesianChart1.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.CartesianChart1.Location = New System.Drawing.Point(12, 55)
        Me.CartesianChart1.Name = "CartesianChart1"
        Me.CartesianChart1.Size = New System.Drawing.Size(636, 283)
        Me.CartesianChart1.TabIndex = 19
        Me.CartesianChart1.Text = "CartesianChart1"
        '
        'Guna2Panel11
        '
        Me.Guna2Panel11.BorderRadius = 10
        Me.Guna2Panel11.Controls.Add(Me.Guna2CircleButton8)
        Me.Guna2Panel11.Controls.Add(Me.Label32)
        Me.Guna2Panel11.Controls.Add(Me.CartesianChart1)
        Me.Guna2Panel11.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Panel11.Location = New System.Drawing.Point(215, 452)
        Me.Guna2Panel11.Name = "Guna2Panel11"
        Me.Guna2Panel11.ShadowDecoration.Parent = Me.Guna2Panel11
        Me.Guna2Panel11.Size = New System.Drawing.Size(667, 356)
        Me.Guna2Panel11.TabIndex = 20
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Label32.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Label32.Location = New System.Drawing.Point(19, 16)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(116, 19)
        Me.Label32.TabIndex = 20
        Me.Label32.Text = "TRANSACTIONS"
        '
        'Guna2Panel12
        '
        Me.Guna2Panel12.BorderRadius = 10
        Me.Guna2Panel12.Controls.Add(Me.Guna2DataGridView1)
        Me.Guna2Panel12.Controls.Add(Me.Guna2CircleButton9)
        Me.Guna2Panel12.Controls.Add(Me.Label33)
        Me.Guna2Panel12.Controls.Add(Me.PieChart1)
        Me.Guna2Panel12.FillColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Guna2Panel12.Location = New System.Drawing.Point(901, 452)
        Me.Guna2Panel12.Name = "Guna2Panel12"
        Me.Guna2Panel12.ShadowDecoration.Parent = Me.Guna2Panel12
        Me.Guna2Panel12.Size = New System.Drawing.Size(434, 355)
        Me.Guna2Panel12.TabIndex = 21
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.Label33.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(23, 19)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(103, 19)
        Me.Label33.TabIndex = 21
        Me.Label33.Text = "ALL EXPENSES"
        '
        'PieChart1
        '
        Me.PieChart1.BackColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.PieChart1.Location = New System.Drawing.Point(19, 135)
        Me.PieChart1.Name = "PieChart1"
        Me.PieChart1.Size = New System.Drawing.Size(402, 203)
        Me.PieChart1.TabIndex = 0
        Me.PieChart1.Text = "PieChart1"
        '
        'Guna2CircleButton8
        '
        Me.Guna2CircleButton8.Animated = True
        Me.Guna2CircleButton8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton8.CheckedState.Parent = Me.Guna2CircleButton8
        Me.Guna2CircleButton8.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.right_arrow_127px2
        Me.Guna2CircleButton8.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.right_arrow_127px1
        Me.Guna2CircleButton8.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton8.CustomImages.Parent = Me.Guna2CircleButton8
        Me.Guna2CircleButton8.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton8.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton8.HoverState.Parent = Me.Guna2CircleButton8
        Me.Guna2CircleButton8.Location = New System.Drawing.Point(623, 10)
        Me.Guna2CircleButton8.Name = "Guna2CircleButton8"
        Me.Guna2CircleButton8.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton8.ShadowDecoration.Parent = Me.Guna2CircleButton8
        Me.Guna2CircleButton8.Size = New System.Drawing.Size(25, 25)
        Me.Guna2CircleButton8.TabIndex = 21
        '
        'Guna2PictureBox6
        '
        Me.Guna2PictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox6.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.playstation_127px
        Me.Guna2PictureBox6.Location = New System.Drawing.Point(165, -6)
        Me.Guna2PictureBox6.Name = "Guna2PictureBox6"
        Me.Guna2PictureBox6.ShadowDecoration.Parent = Me.Guna2PictureBox6
        Me.Guna2PictureBox6.Size = New System.Drawing.Size(84, 73)
        Me.Guna2PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox6.TabIndex = 12
        Me.Guna2PictureBox6.TabStop = False
        '
        'Guna2PictureBox5
        '
        Me.Guna2PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox5.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.amazon_127px
        Me.Guna2PictureBox5.Location = New System.Drawing.Point(193, 0)
        Me.Guna2PictureBox5.Name = "Guna2PictureBox5"
        Me.Guna2PictureBox5.ShadowDecoration.Parent = Me.Guna2PictureBox5
        Me.Guna2PictureBox5.Size = New System.Drawing.Size(51, 55)
        Me.Guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox5.TabIndex = 12
        Me.Guna2PictureBox5.TabStop = False
        '
        'Guna2PictureBox4
        '
        Me.Guna2PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox4.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.mcdonald_127px
        Me.Guna2PictureBox4.Location = New System.Drawing.Point(181, 3)
        Me.Guna2PictureBox4.Name = "Guna2PictureBox4"
        Me.Guna2PictureBox4.ShadowDecoration.Parent = Me.Guna2PictureBox4
        Me.Guna2PictureBox4.Size = New System.Drawing.Size(82, 52)
        Me.Guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox4.TabIndex = 12
        Me.Guna2PictureBox4.TabStop = False
        '
        'Guna2PictureBox3
        '
        Me.Guna2PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox3.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.ebay_127px
        Me.Guna2PictureBox3.Location = New System.Drawing.Point(139, -15)
        Me.Guna2PictureBox3.Name = "Guna2PictureBox3"
        Me.Guna2PictureBox3.ShadowDecoration.Parent = Me.Guna2PictureBox3
        Me.Guna2PictureBox3.Size = New System.Drawing.Size(124, 85)
        Me.Guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox3.TabIndex = 12
        Me.Guna2PictureBox3.TabStop = False
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.mastercard_logo_127px
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(280, 9)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.ShadowDecoration.Parent = Me.Guna2PictureBox2
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(60, 42)
        Me.Guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox2.TabIndex = 1
        Me.Guna2PictureBox2.TabStop = False
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.chip_card_127px_png2
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(15, 61)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.ShadowDecoration.Parent = Me.Guna2PictureBox1
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(60, 42)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox1.TabIndex = 0
        Me.Guna2PictureBox1.TabStop = False
        '
        'Guna2CircleButton9
        '
        Me.Guna2CircleButton9.Animated = True
        Me.Guna2CircleButton9.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton9.CheckedState.Parent = Me.Guna2CircleButton9
        Me.Guna2CircleButton9.CustomImages.HoveredImage = Global.Finacial_Apps_Dashboard.My.Resources.Resources.right_arrow_127px2
        Me.Guna2CircleButton9.CustomImages.Image = Global.Finacial_Apps_Dashboard.My.Resources.Resources.right_arrow_127px1
        Me.Guna2CircleButton9.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Guna2CircleButton9.CustomImages.Parent = Me.Guna2CircleButton9
        Me.Guna2CircleButton9.FillColor = System.Drawing.Color.Transparent
        Me.Guna2CircleButton9.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton9.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton9.HoverState.Parent = Me.Guna2CircleButton9
        Me.Guna2CircleButton9.Location = New System.Drawing.Point(396, 16)
        Me.Guna2CircleButton9.Name = "Guna2CircleButton9"
        Me.Guna2CircleButton9.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton9.ShadowDecoration.Parent = Me.Guna2CircleButton9
        Me.Guna2CircleButton9.Size = New System.Drawing.Size(25, 25)
        Me.Guna2CircleButton9.TabIndex = 22
        '
        'Guna2DataGridView1
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.Guna2DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Guna2DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.Guna2DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.Guna2DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Guna2DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Guna2DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(16, Byte), Integer), CType(CType(18, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Guna2DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Guna2DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Guna2DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(41, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(114, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Guna2DataGridView1.DefaultCellStyle = DataGridViewCellStyle3
        Me.Guna2DataGridView1.EnableHeadersVisualStyles = False
        Me.Guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(62, Byte), Integer))
        Me.Guna2DataGridView1.Location = New System.Drawing.Point(20, 47)
        Me.Guna2DataGridView1.Name = "Guna2DataGridView1"
        Me.Guna2DataGridView1.RowHeadersVisible = False
        Me.Guna2DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Guna2DataGridView1.Size = New System.Drawing.Size(390, 83)
        Me.Guna2DataGridView1.TabIndex = 23
        Me.Guna2DataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Dark
        Me.Guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.Guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.Guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.Guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.Guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.Guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.Guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(62, Byte), Integer))
        Me.Guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(16, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.Guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.Guna2DataGridView1.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.Guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 15
        Me.Guna2DataGridView1.ThemeStyle.ReadOnly = False
        Me.Guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.Guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.Guna2DataGridView1.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.White
        Me.Guna2DataGridView1.ThemeStyle.RowsStyle.Height = 22
        Me.Guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(114, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.Guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White
        '
        'Column1
        '
        Me.Column1.HeaderText = "Daily"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Weekly"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "Monthly"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "Total"
        Me.Column4.Name = "Column4"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(39, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1358, 840)
        Me.Controls.Add(Me.Guna2Panel12)
        Me.Controls.Add(Me.Guna2Panel11)
        Me.Controls.Add(Me.Guna2Panel10)
        Me.Controls.Add(Me.Guna2Panel9)
        Me.Controls.Add(Me.Guna2Panel8)
        Me.Controls.Add(Me.Guna2Panel7)
        Me.Controls.Add(Me.Guna2GradientPanel1)
        Me.Controls.Add(Me.Guna2Panel6)
        Me.Controls.Add(Me.Guna2Panel3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel2.PerformLayout()
        Me.Guna2Panel3.ResumeLayout(False)
        Me.Guna2Panel5.ResumeLayout(False)
        Me.Guna2Panel5.PerformLayout()
        Me.Guna2Panel4.ResumeLayout(False)
        Me.Guna2Panel4.PerformLayout()
        Me.Guna2Panel6.ResumeLayout(False)
        Me.Guna2Panel6.PerformLayout()
        Me.Guna2GradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel1.PerformLayout()
        Me.Guna2Panel7.ResumeLayout(False)
        Me.Guna2Panel7.PerformLayout()
        Me.Guna2Panel8.ResumeLayout(False)
        Me.Guna2Panel8.PerformLayout()
        Me.Guna2Panel9.ResumeLayout(False)
        Me.Guna2Panel9.PerformLayout()
        Me.Guna2Panel10.ResumeLayout(False)
        Me.Guna2Panel10.PerformLayout()
        Me.Guna2Panel11.ResumeLayout(False)
        Me.Guna2Panel11.PerformLayout()
        Me.Guna2Panel12.ResumeLayout(False)
        Me.Guna2Panel12.PerformLayout()
        CType(Me.Guna2PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2DragControl1 As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents Guna2Separator1 As Guna.UI2.WinForms.Guna2Separator
    Friend WithEvents Guna2CircleButton1 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button3 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button5 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button6 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button7 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button8 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button10 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button11 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button9 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button12 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button13 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button15 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button14 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button16 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button18 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button17 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel3 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel5 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel4 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Guna2Button20 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2CircleButton2 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2Button19 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label12 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Guna2Panel6 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2GradientPanel1 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2Panel7 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2CircleButton3 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Guna2PictureBox3 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Guna2Button21 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel10 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Button24 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox6 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Guna2CircleButton6 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Label31 As Label
    Friend WithEvents Guna2Panel9 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Button23 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox5 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Guna2CircleButton5 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Label28 As Label
    Friend WithEvents Guna2Panel8 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Button22 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox4 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Guna2CircleButton4 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Label25 As Label
    Friend WithEvents Guna2ControlBox3 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2ControlBox2 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2ControlBox1 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2CircleButton7 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2Panel12 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Label33 As Label
    Friend WithEvents PieChart1 As LiveCharts.WinForms.PieChart
    Friend WithEvents Guna2Panel11 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Label32 As Label
    Friend WithEvents CartesianChart1 As LiveCharts.WinForms.CartesianChart
    Friend WithEvents Guna2CircleButton8 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2CircleButton9 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2DataGridView1 As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
End Class
